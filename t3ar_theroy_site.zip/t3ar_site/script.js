// Minimal cart behavior (client-side placeholder)
const addBtn = document.querySelector('.add');
addBtn && addBtn.addEventListener('click', ()=>{
  alert('Added to cart (client-side placeholder). Replace with real checkout when ready.');
});

function submitContact(e){
  e.preventDefault();
  const f = e.target;
  const subject = encodeURIComponent('Contact from website — ' + f.name.value);
  const body = encodeURIComponent('Name: ' + f.name.value + '\nEmail: ' + f.email.value + '\n\n' + f.message.value);
  window.location.href = 'mailto:hello@t3artheroy.com?subject=' + subject + '&body=' + body;
  return false;
}
